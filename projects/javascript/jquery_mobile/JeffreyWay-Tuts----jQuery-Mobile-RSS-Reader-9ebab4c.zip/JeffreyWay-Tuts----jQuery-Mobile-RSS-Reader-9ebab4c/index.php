<?php include('includes/header.php'); ?> 
<body>
 <div data-role="page">
   <header data-role="header" class="tuts">
     <h1>
       <img src="img/TLogo.png" alt="Tuts+" />
     </h1>
   </header>
   <!-- /header -->

   <div data-role="content">
     <ul data-role="listview" data-theme="c" data-dividertheme="d" data-counttheme="e">
       <li>
         <img src="img/ntLogo.jpg" alt="Nettuts" class="ui-li-icon" />
         <a href="site.php?siteName=nettuts"> Nettuts+ </a>
       </li>
       <li>
         <img src="img/psdLogo.jpg" alt="Psdtuts" class="ui-li-icon" />
         <a href="site.php?siteName=psdtuts"> Psdtuts+ </a>
       </li>
       <li>
         <img src="img/vectorLogo.jpg" alt="Vectortuts+" class="ui-li-icon" />
         <a href="site.php?siteName=vectortuts"> Vectortuts+ </a>
       </li>
       <li>
         <img src="img/mobileLogo.png" alt="Mobiletuts+" class="ui-li-icon" />
         <a href="site.php?siteName=mobiletuts"> Mobiletuts+ </a>
       </li>
       <li>
         <img src="img/aeLogo.jpg" alt="Aetuts+" class="ui-li-icon" />
         <a href="site.php?siteName=aetuts"> Aetuts+ </a>
       </li>
       <li>
         <img src="img/photoLogo.jpg" alt="Phototuts+" class="ui-li-icon" />
         <a href="site.php?siteName=phototuts"> Phototuts+ </a>
       </li>
       <li>
         <img src="img/cgLogo.jpg" alt="Cgtuts+" class="ui-li-icon" />
         <a href="site.php?siteName=cgtuts"> Cgtuts+ </a>
       </li>
       <li>
         <img src="img/audioLogo.jpg" alt="Audiotuts+" class="ui-li-icon" />
         <a href="site.php?siteName=audiotuts"> Audiotuts+ </a>
       </li>
       <li>
         <img src="img/activeLogo.jpg" alt="Activetuts+" class="ui-li-icon" />
         <a href="site.php?siteName=flashtuts"> Activetuts+ </a>
       </li>
       <li>
         <img src="img/wdLogo.jpg" alt="Webdesigntuts+" class="ui-li-icon" />
         <a href="site.php?siteName=webdesigntutsplus"> Webdesigntuts+ </a>
       </li>
     </ul>
   </div>

   <footer data-role="footer" class="tuts">
      <h4> www.tutsplus.com </h4>
   </footer>

 </div>
 <!-- /page -->
</body>
</html>

