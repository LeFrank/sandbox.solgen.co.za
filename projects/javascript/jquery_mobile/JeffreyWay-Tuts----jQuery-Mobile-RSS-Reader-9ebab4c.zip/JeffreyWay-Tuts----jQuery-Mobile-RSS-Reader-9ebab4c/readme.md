This is a relatively simple Tuts+ RSS reader. It's currently a work in development. 

<img src="http://content.screencast.com/users/JeffreyWay/folders/Jing/media/7f4d2878-d3c8-459e-99ca-68059d8ff3ce/00000097.png" alt="Example" />
