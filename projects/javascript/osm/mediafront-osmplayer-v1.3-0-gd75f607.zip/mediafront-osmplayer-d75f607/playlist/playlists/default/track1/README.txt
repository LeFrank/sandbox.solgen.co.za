Place either a video file (MOV, MP4, or FLV) or music file (MP3, WAV) along with whatever image
you would like to associate in this this folder.