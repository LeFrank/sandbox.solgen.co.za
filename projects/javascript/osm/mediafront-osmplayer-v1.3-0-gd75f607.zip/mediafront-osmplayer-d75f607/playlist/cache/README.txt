This is the cache folder to be used to store cached XML files when a playlist is generated.
When you add new songs to your playlist, you MUST delete all the contents of this folder
for your change to take affect.