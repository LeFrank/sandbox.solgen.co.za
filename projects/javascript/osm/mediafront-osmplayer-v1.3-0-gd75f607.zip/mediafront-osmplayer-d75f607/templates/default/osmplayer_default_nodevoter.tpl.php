<div id="<?php print $params['prefix']; ?>medianodevoter">
  <div id="<?php print $params['prefix']; ?>mediavoterstext">
    <div id="<?php print $params['prefix']; ?>mediauservotertext">Vote:</div>
    <div id="<?php print $params['prefix']; ?>mediavotertext">Average:</div>
  </div>
  <div id="<?php print $params['prefix']; ?>mediavoters">
    <div id="<?php print $params['prefix']; ?>mediauservoter" tag="vote">
      <div vote="20">
        <span class="<?php print $params['prefix']; ?>ui-icon <?php print $params['prefix']; ?>ui-icon-star"></span>
      </div>
      <div vote="40">
        <span class="<?php print $params['prefix']; ?>ui-icon <?php print $params['prefix']; ?>ui-icon-star"></span>
      </div>
      <div vote="60">
        <span class="<?php print $params['prefix']; ?>ui-icon <?php print $params['prefix']; ?>ui-icon-star"></span>
      </div>
      <div vote="80">
        <span class="<?php print $params['prefix']; ?>ui-icon <?php print $params['prefix']; ?>ui-icon-star"></span>
      </div>
      <div vote="100">
        <span class="<?php print $params['prefix']; ?>ui-icon <?php print $params['prefix']; ?>ui-icon-star"></span>
      </div>
    </div>
    <div id="<?php print $params['prefix']; ?>mediavoter" tag="vote">
      <div vote="20">
        <span class="<?php print $params['prefix']; ?>ui-icon <?php print $params['prefix']; ?>ui-icon-star"></span>
      </div>
      <div vote="40">
        <span class="<?php print $params['prefix']; ?>ui-icon <?php print $params['prefix']; ?>ui-icon-star"></span>
      </div>
      <div vote="60">
        <span class="<?php print $params['prefix']; ?>ui-icon <?php print $params['prefix']; ?>ui-icon-star"></span>
      </div>
      <div vote="80">
        <span class="<?php print $params['prefix']; ?>ui-icon <?php print $params['prefix']; ?>ui-icon-star"></span>
      </div>
      <div vote="100">
        <span class="<?php print $params['prefix']; ?>ui-icon <?php print $params['prefix']; ?>ui-icon-star"></span>
      </div>
    </div>
  </div>
</div>