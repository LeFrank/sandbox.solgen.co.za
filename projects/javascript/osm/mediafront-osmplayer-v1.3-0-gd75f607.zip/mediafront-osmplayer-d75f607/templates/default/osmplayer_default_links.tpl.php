<div id="<?php print $params['prefix']; ?>medialinks">
  <div id="<?php print $params['prefix']; ?>medialinkscroll">
    <div id="<?php print $params['prefix']; ?>medialist">
      <div id="<?php print $params['prefix']; ?>medialink">
        <div id="<?php print $params['prefix']; ?>medialinktext">Link</div>
      </div>
    </div>
  </div>
</div>
