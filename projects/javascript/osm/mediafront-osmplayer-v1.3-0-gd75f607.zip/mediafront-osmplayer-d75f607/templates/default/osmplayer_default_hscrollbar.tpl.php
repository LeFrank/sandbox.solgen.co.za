<div id="<?php print $params['prefix']; ?>mediascrollbarwrapper" class="<?php print $params['prefix']; ?>hmediascrollbarwrapper">
  <div class="<?php print $params['prefix']; ?>hmediascrollleft">
    <div id="<?php print $params['prefix']; ?>mediascrollup" class="<?php print $params['prefix']; ?>hmediascrollup <?php print $params['prefix']; ?>ui-state-default"><span class="<?php print $params['prefix']; ?>ui-icon <?php print $params['prefix']; ?>ui-icon-triangle-1-w"></span></div>
    <div id="<?php print $params['prefix']; ?>mediascrollbar" class="<?php print $params['prefix']; ?>hmediascrollbar">
      <div id="<?php print $params['prefix']; ?>mediascrollhandle" class="<?php print $params['prefix']; ?>ui-state-default">
        <span class="<?php print $params['prefix']; ?>ui-icon <?php print $params['prefix']; ?>ui-icon-grip-dotted-horizontal"></span>
      </div>
      <div id="<?php print $params['prefix']; ?>mediascrolltrack" class="<?php print $params['prefix']; ?>ui-widget-content"></div>
    </div>
  </div>
  <div id="<?php print $params['prefix']; ?>mediascrolldown" class="<?php print $params['prefix']; ?>hmediascrolldown <?php print $params['prefix']; ?>ui-state-default"><span class="<?php print $params['prefix']; ?>ui-icon <?php print $params['prefix']; ?>ui-icon-triangle-1-e"></span></div>
</div> 
<div class="<?php print $params['prefix']; ?>ui-helper-clearfix"></div>  