<?php
include( 'createJS.inc');
create_javascript_release( $argv[1] );
?>