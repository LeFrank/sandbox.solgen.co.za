#!/bin/bash
DIR="$( cd "$( dirname "$0" )" && pwd )"
php $DIR/createJS.php "$DIR/../"