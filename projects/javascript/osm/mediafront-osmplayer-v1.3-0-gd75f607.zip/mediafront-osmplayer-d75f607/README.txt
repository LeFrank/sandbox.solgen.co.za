Open Standard Media Player - Build by Alethia Inc. (c) 2011.  
 
http://www.mediafront.org - For documentaion, implementations, and examples...
http://www.alethia-inc.com - For customization inquiries and business prospects.

ABOUT:
   The open standard media player is an open source GPL - license free - full featured media player written in jQuery.
   It was designed to dynamically play any media thrown it's way, whether it be HTML5 video - Flash video - Audio, etc.

   Although this media player was designed to be used within a Content Management environment, such as Drupal, you can
   use this player for other applications outside of a CMS.

USAGE:
   For usage in Drupal Content Management System:   
      Simply download and install the MediaFront module http://www.drupal.org/project/mediafront.
   
   For usage outside of Drupal.
      Open up the index.html page and observe how this player is created and used.  
   
   
NEED HELP OR CUSTOMIZATIONS?
   If you require any assistance, please visit Alethia Design's website at http://www.alethia-inc.com and inquire
   using our Contact Form.  We will get back with you shortly.
   
ENJOY!
